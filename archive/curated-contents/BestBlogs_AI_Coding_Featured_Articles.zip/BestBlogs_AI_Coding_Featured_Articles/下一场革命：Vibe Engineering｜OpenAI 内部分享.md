---
title: "下一场革命：Vibe Engineering｜OpenAI 内部分享"
url: https://mp.weixin.qq.com/s?__biz=MzkzNDQxOTU2MQ==&mid=2247509763&idx=1&sn=10861cba3438be83ccabf1dcc988859a
---

# 下一场革命：Vibe Engineering｜OpenAI 内部分享

OpenAI 办了一场内部分享，主题是 **Vibe Engineering** ，这里区别于「**Vibe Coding** 」，具体为啥，容我细细道来

Developer Experience 负责人 Romain Huet 和工程师 Aaron Friel 讲了一个数据：
> OpenAI 内部技术人员的 Codex 采用率超过 92%，所有内部 PR 都由 Codex 审核，使用 Codex 的工程师产出的合并 PR 比不用的多 70%
![](https://image.jido.dev/20251215001918_2c28ac5d) 发生在 OpenAI 内部的革命

Friel 也讲的另一个故事：
> 让 Codex 跑了 7 小时，迭代了 200 多轮测试，最终产出的 diff 只有大约 500 行

**代码行数越来越便宜了，但证明代码有效这件事，变贵了**
![](https://image.jido.dev/20251215001918_53ad2e90) 代码越来越便宜，信任越来越贵

12 小时，从空目录到完整项目
---------------

分享会上， Friel 做了个现场演示   
把一个叫 Bazel Diff 的 Kotlin 项目用 Rust 从零重写，要求 100% 兼容原项目
![](https://image.jido.dev/20251215001918_3ded97e2) 12 小时，从空目录到完整项目

起点是一个空目录，里面只有一个 prompt 文件   
Friel 把 prompt 贴进 Codex CLI，然后就....等着

Codex 做的第一件事不是写代码，是创建一个「watchdog」子代理------专门用来提醒主代理「你的目标是什么、用户的要求是什么」，防止跑偏

然后它启动了一堆子代理并行工作，有的用 GPT 5.1，有的用 Codex Mini，分别去研究上游项目的代码、调研 Bazel 8 和 Bazel 9 的差异、设计项目架构

所有进度都记录在一个叫「exec plan」的文件里------不只是给模型看的，也是给人看的

Friel 说他之前晚上跑过一次完整的，大概 12 小时跑完   
这个任务如果让工程师手写，大概需要几周

7 小时 500 行的故事
-------------

这是 Friel 在 Dev Day 讲过的故事，现在有了更多细节   
当时他在沙发上边看电视边干活，顺手把电脑设成不休眠，让 Codex 跑一个任务   
第二天早上醒来发现 Codex 还在跑

7 小时，200 多轮迭代，最终产出一个大约 500 行的 diff
![](https://image.jido.dev/20251215001918_58ef3752) 7小时，200轮迭代，500行代码

Friel 说很多工程师听到这个数字的第一反应是：   
「完了，写了 10 万行垃圾代码吧？」

但事实相反------这是一个非常复杂的改动，Codex 把大部分时间花在了跑测试、改测试、再跑测试上

最终这个改动被 merge 了

Romain 说这才是新的进度单位：   
**更少的错误、更好的 review、更高的置信度------即使最终的 patch 很小**

Codex 的自我构建
-----------

一个细节：   
**OpenAI 用 Codex 来开发 Codex**
![](https://image.jido.dev/20251215001918_0f5d4098) 系统开始自我优化

Romain 说这就是为什么 Codex 几乎每隔几天就能发一个新版本

recursive self-improvement，从 Codex 开始

非工程师也在用
-------

OpenAI 内部，有一个 Codex 的 Slack 集成，非技术团队可以直接问 Codex 关于代码库的问题

比如产品经理想知道某个功能是怎么实现的，销售想了解某个 API 的细节，不用再去找工程师约会议了
![](https://image.jido.dev/20251215001918_a759ab6a) 技术，流向每一个人

Friel 说：   
Codex 回答这些问题有时候比他自己回答得还好

设计师也在用，比如通过 MCP 连接 Figma，直接把 Figma 组件拉成代码

Romain 的说法是：   
**不是每个人都要变成工程师，但每个人都在变得更技术**

所有工程师都升职了
---------

Friel 开玩笑说：   
**现在所有工程师都变成 Manager 了**

因为你不再是自己写代码，而是给 Codex 分配任务、审核它的产出

而且 Codex 还会自己创建子代理、给子代理分配任务

所以准确说，大家都变成 Director 了
![](https://image.jido.dev/20251215001918_abfafa7b) 所有人都升职了

Best of N
---------

Codex 有一个功能叫「Best of N」   
你给它一个任务，它可以并行尝试 4 种不同的方案，然后把 4 个结果的截图都给你看
![](https://image.jido.dev/20251215001918_8f819d66) 并行探索

Friel 说他经常用这个功能------先看 4 个方案，挑一个最顺眼的，然后继续迭代

Romain 的说法是：   
这就是创意流动的方式，让 AI 想 4 个方案供你挑选

什么变重要了
------

关于这些工具带来的能力瓶颈转移，Romain 讲得很直接：

* • 设计和品味（taste）

* • 判断力（discernment）

* • 清晰的沟通

还有一个：   
**产出让人类愿意读的东西**
![](https://image.jido.dev/20251215001918_b67d8486) 「重要」的迁移

Friel 说他有一个测试标准   
如果 Codex 的产出是你自己不想读的东西，那它对 AI 代理也不会有用

他们在推动工程师多写文档、多写测试的理由也是这个：   
**这些东西，不只是给人看的，也是给下一个接手这个代码库的 AI 代理看的**

话说回来
----

Simon Willison 提出「Vibe Engineering」这个词   
是为了跟「Vibe Coding」区分开

Vibe Coding 是让模型随便写代码然后祈祷测试能过   
Vibe Engineering 是高级工程师对每一行代码负责，但在规划、架构、调试、文档各个环节都用上代理

**要用 AI 构建，也要保持人类的责任**
