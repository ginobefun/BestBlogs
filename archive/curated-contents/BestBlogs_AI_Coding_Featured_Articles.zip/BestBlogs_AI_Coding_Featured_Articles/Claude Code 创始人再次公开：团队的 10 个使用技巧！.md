---
title: "Claude Code 创始人再次公开：团队的 10 个使用技巧！"
url: https://mp.weixin.qq.com/s?__biz=MzIyNjM2MzQyNg==&mid=2247718904&idx=1&sn=7f77ee06ab57fd11bc44ab6f782cd644
---

# Claude Code 创始人再次公开：团队的 10 个使用技巧！

![](https://image.jido.dev/20260204045043_7142c4b.jpeg)

### Datawhale干货
**作****者：**Boris**，Claude Code创始人**

年初，Claude Code 创始人 Boris Cherny 在 X 上首次公开了他的[个人Claude Code使用技巧](https://mp.weixin.qq.com/s?__biz=MzIyNjM2MzQyNg==&mid=2247717240&idx=1&sn=dfd0b8b79fb18e53d17d62ef149aa392&scene=21#wechat_redirect)。

![](https://image.jido.dev/20260204045043_10f6534.png)  
前天，Claude Code 创始人 Boris Cherny 在X上再次公开了 Claude Code 团队的 10 个使用技巧，干货满满。

![](https://image.jido.dev/20260204045043_88e843f.png)

以下是 Boris 的原文，Datawhale团队翻译：

大家好，我是 Boris，Claude Code 的创建者。想跟大家简要分享一些直接来自 Claude Code 团队内部的使用技巧。其实，团队成员的用法和我的习惯并不太一样。**请记住：使用 Claude Code 并没有所谓的唯一正解** ------毕竟每个人的配置环境都各不相同。建议大家多做尝试，找到最适合自己的工作流！

****Claude Code 团队的 10 个使用技巧****

### 1. 并行处理更多任务

同时开启 3--5 个 git worktree，让每个 worktree 都运行独立的 Claude 会话并行工作。这是提升效率的最有效方法，也是团队推荐的首要技巧。我个人习惯使用多个 git checkout 目录，但 Claude Code 团队的大多数成员都更偏爱 worktree------正因如此，@amorriscode 专门在 Claude Desktop 应用里为 worktree 开发了**原生支持** ！

有些人还会给 worktree 命名并设置 **Shell 别名** （比如 za、zb、zc），这样就能通过键盘指令在不同任务间**一键切换** 。还有人会预留一个专门的"分析用" worktree，仅用来查看日志和运行 BigQuery。

参阅文档：
<https://code.claude.com/docs/en/common-workflows>#run-parallel-claude-code-sessions-with-git-worktrees

![](https://image.jido.dev/20260204045043_1159c88.jpeg)

### 2. 任何复杂任务，都从 Plan Mode 开始

把精力集中在打磨计划上，这样 Claude 在实现代码时就能**一步到位** （1-shot）。

团队里有个成员的做法是：先让一个 Claude 写出计划，然后启动第二个 Claude，让它代入 **Staff Engineer** （资深工程师）的角色来对计划进行 **Review** （审查）。

还有成员建议：一旦发现进展**跑偏** （go sideways），立刻切回 Plan Mode **重新规划** 。千万别**硬推** 。他们甚至会明确指示 Claude 在**验证步骤** 中也要进入 Plan Mode，而不仅仅是在构建代码的时候才用。

![](https://image.jido.dev/20260204045042_23a0c39.png)

### 3. 用心经营你的 CLAUDE.md

要在 CLAUDE.md 上多下功夫。每次纠正完 Claude 的问题后，记得在结尾加一句："**把这条更新到 CLAUDE.md 里，确保下次别再犯同样的错误。** " Claude 在"给自己制定规则"这方面，能力**强得离谱** （eerily good）。

随着时间推移，你要**大刀阔斧** （ruthlessly）地编辑你的 CLAUDE.md。保持迭代，直到你能感觉到 Claude 的错误率**显著下降** 为止。

有一位工程师的用法是：让 Claude 为每个任务或项目维护一个**笔记目录** ，并且在每次 PR（代码合并）后都去更新它。然后，他在 CLAUDE.md 里直接引用这个目录作为索引。

![](https://image.jido.dev/20260204045043_789285d.png)

### 4. **创建你自己的专属 Skill 并提交到 Git，在所有项目中复用**

团队给出的建议如下：

* **封装复用** ：如果某个操作你每天要重复不止一次，就应该把它**封装** 成一个 Skill 或指令。

* **清理技术债** ：做一个 /techdebt 的斜杠命令（Slash Command），每次会话结束时跑一下，专门用来**揪出并干掉** （find and kill）重复代码。

* **上下文聚合** ：设置一个命令，用来抓取过去 7 天内的 Slack、GDrive、Asana 和 GitHub 数据，并把它们**一次性打包** 成一份上下文汇总（Context Dump）。

* **专用 Agent** ：构建像**数据分析工程师** （Analytics Engineer）那样的 Agent，让它们专门负责编写 dbt 模型、Code Review 以及在 Dev 环境中测试变更。

了解更多：<https://code.claude.com/docs/en/skills#extend-claude-with-skills>

![](https://image.jido.dev/20260204045043_37743a0.jpeg)

### 5. Claude 几乎能自主搞定大部分 Bug。

### 我们是这么做的：

开启 Slack MCP 插件，然后把 Slack 里的 Bug 讨论串直接贴给 Claude，只说一句"fix"就行，完全不需要在不同工具间切来切去。

或者，直接跟它说"去把失败的 CI 测试修了"，不用管它具体怎么修。

还可以把 Docker 日志丢给 Claude 让它去排查分布式系统------它在这方面的表现好得惊人。

![](https://image.jido.dev/20260204045043_cf5298b.png)

**6. 提升你的 Prompt 技巧**

**a. 挑战 Claude：** 对它说："针对这些改动向我提问，在我通过你的测试之前不要提交 PR。"让 Claude 担任你的评审员。或者说："证明这套方案行得通"，让它对比 main 分支和 feature 分支的行为差异。

**b. 如果修复方案不够理想，可以对它说：** "基于你现在掌握的信息，推翻刚才的方案，换一个更优雅的实现。"

**c. 在交付任务前，先写好详尽的规格说明（Specs）以减少歧义。** 你写得越具体，它的输出质量就越高。

7. 终端与环境配置

团队非常推崇 Ghostty！很多人喜欢它的同步渲染、24 位色彩以及对 Unicode 的完美支持。

为了更方便地管理 Claude，可以利用 /statusline 自定义状态栏，让它始终显示上下文占用情况和当前的 Git 分支。我们中还有许多人习惯给终端标签页设置颜色和命名（有时配合 tmux 使用），每个任务或工作树（worktree）占用一个标签。

使用语音听写。你说话的速度比打字快 3 倍，这样写出来的 Prompt 也会因此详尽得多（在 macOS 上连按两次 fn 键即可开启）。

更多技巧请参考：
<https://code.claude.com/docs/en/terminal-config>

![](https://image.jido.dev/20260204045043_631db9d.png)

**8. 使用子智能体（Subagents）**

**a. 增加算力投入：** 在任何请求后加上"use subagents"，如果你希望 Claude 投入更多算力来解决某个问题。

**b. 任务卸载：** 将独立任务分配给子智能体，这样可以保持主智能体（Main Agent）的上下文窗口（Context Window）整洁且聚焦。

**c. 权限审批自动化：** 通过 Hook 将权限请求路由给 Opus 4.5------让它扫描是否存在攻击风险，并自动批准安全的请求（详见
<https://code.claude.com/docs/en/hooks#permissionrequest>
）。

![](https://image.jido.dev/20260204045043_b54a061.png)

**9. 使用 Claude 进行数据分析**

让 Claude Code 调用 bq 命令行工具，即时获取并分析指标。我们将一个 BigQuery 技能（Skill）提交到了代码库中，团队里的每个人都会直接在 Claude Code 里用它跑分析查询。就我个人而言，我已经有 6 个多月没亲手写过一行 SQL 了。

这种方式适用于任何拥有命令行工具（CLI）、MCP 插件或 API 的数据库。

**10. 利用 Claude 进行学习**

分享一些团队内部使用 Claude Code 辅助学习的小贴士：

**a. 开启解释模式：** 在 /config 中启用 "Explanatory（解释型）" 或 "Learning（学习型）" 输出风格，让 Claude 解释代码改动背后的**原委** 。

**b. 生成可视化简报：** 让 Claude 生成一个用于解释陌生代码的可视化 HTML 演示文稿。它做出来的幻灯片效果好得惊人！

**c. 绘制 ASCII 架构图：** 让 Claude 针对新协议或代码库绘制 ASCII 流程图，这能帮你快速理清逻辑。

**d. 构建间隔重复学习技能：** 打造一个基于"间隔重复（Spaced-repetition）"的学习技能------先由你解释自己的理解，Claude 通过追问来填补你的知识盲区，并记录学习结果。

<br />

