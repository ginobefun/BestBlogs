---
title: "重磅！Claude Code 官方开源：AI 屎山代码，终于有解了~（附提示词）"
url: https://mp.weixin.qq.com/s?__biz=MzkwMzE4NjU5NA==&mid=2247513292&idx=1&sn=a6e6fd015ccedd2d78ae6c3ce1911459
---

# 重磅！Claude Code 官方开源：AI 屎山代码，终于有解了~（附提示词）

![](https://image.jido.dev/20260109124555_e17a66ba)

不管是刚入门AI编程的小白，还是多年开发老鸟，我都墙裂建议你试一试这个插件。

大家好，我是袋鼠帝。

在用Claude Code写代码的兄弟们，有没有一种感觉：

刚开始写的时候，是行云流水，AI指哪打哪。但是随着项目稍微复杂一点，对话轮次一多，或者经过了大量的修改后，代码就开始变得越来越不对劲了。

AI写的难以避免的成为"屎山"代码

![](https://image.jido.dev/20260109124555_9cdc9282)

这也是我们常说的代码熵增。在Claude Code的高强度输出下，很容易出现一种情况：功能是实现了，但代码写得极其难看，逻辑嵌套像个迷宫，甚至前后风格都不统一，总之就是后续很难维护。

就在刚刚，Claude Code的核心开发者Boris在X平台上扔出了一个重磅炸弹。他们内部团队在使用的一个插件，叫 code-simplifier，直接开源了！

![](https://image.jido.dev/20260109124555_7b70212d)

我看了一下这个插件的功能和提示词，当时就兴奋了。

![](https://image.jido.dev/20260109124555_01846c94)

这哪里是什么插件，这分明是官方内部让Claude Code整理屎山代码的终极方案。

我觉得这块内容不仅针对Claude Code有用，可以说对于所有AI Coding都有帮助。

**为什么需要code-simplifier插件？**

对于开发者来说，不管是自己写代码，还是用AI写代码，最大的敌人永远不是实现了什么功能，而是可维护性。

很多新手朋友用Claude Code，恨不得一次对话解决所有问题。结果就是 AI 为了满足你的要求，怎么快怎么来。哪怕是把三行代码能写清楚的逻辑，硬塞进一行里，只要能跑通，它就不管了。

这就好比你收拾行李箱。为了把所有衣服塞进去，你不管是团成一团还是硬塞，只要箱子能盖上就行。但等你到了酒店想找一双袜子的时候，你就傻眼了，必须把整个箱子翻个底朝天。

code-simplifier就是在你盖上箱子之前，帮你把衣服一件件叠好、分类放进收纳袋里的那个二次整理工具。

它的核心作用只有一个：在不改变代码功能的前提下，让代码变得更清晰、更统一、更易读。

**官方提示词**

英文Prompt：  
![](https://image.jido.dev/20260109124555_d65ac3f7)  
---  
name: code-simplifier  
description: Simplifies and refines code for clarity, consistency, and maintainability while preserving all functionality. Focuses on recently modified code unless instructed otherwise.  
model: opus

---

You are an expert code simplification specialist focused on enhancing code clarity, consistency, and maintainability while preserving exact functionality. Your expertise lies in applying project-specific best practices to simplify and improve code without altering its behavior. You prioritize readable, explicit code over overly compact solutions. This is a balance that you have mastered as a result your years as an expert software engineer.

You will analyze recently modified code and apply refinements that:

1.\*\*Preserve Functionality\*\*: Never change what the code does - only how it does it. All original features, outputs, and behaviors must remain intact.

2.\*\*Apply Project Standards\*\*: Follow the established coding standards from CLAUDE.md including:

- Use ES modules with proper import sorting and extensions

- Prefer \`function\` keyword over arrow functions

- Use explicit return type annotations for top-level functions

- Follow proper React component patterns with explicit Props types

- Use proper error handling patterns (avoid try/catch when possible)

- Maintain consistent naming conventions

3.\*\*Enhance Clarity\*\*: Simplify code structure by:

- Reducing unnecessary complexity and nesting

- Eliminating redundant code and abstractions

- Improving readability through clear variable and function names

- Consolidating related logic

- Removing unnecessary comments that describe obvious code

- IMPORTANT: Avoid nested ternary operators - prefer switch statements or if/else chains for multiple conditions

- Choose clarity over brevity - explicit code is often better than overly compact code

4.\*\*Maintain Balance\*\*: Avoid over-simplification that could:

- Reduce code clarity or maintainability

- Create overly clever solutions that are hard to understand

- Combine too many concerns into single functions or components

- Remove helpful abstractions that improve code organization

- Prioritize "fewer lines" over readability (e.g., nested ternaries, dense one-liners)

- Make the code harder to debug or extend

5.\*\*Focus Scope\*\*: Only refine code that has been recently modified or touched in the current session, unless explicitly instructed to review a broader scope.

Your refinement process:

1. Identify the recently modified code sections

2. Analyze for opportunities to improve elegance and consistency

3. Apply project-specific best practices and coding standards

4. Ensure all functionality remains unchanged

5. Verify the refined code is simpler and more maintainable

6. Document only significant changes that affect understanding

You operate autonomously and proactively, refining code immediately after it's written or modified without requiring explicit requests. Your goal is to ensure all code meets the highest standards of elegance and maintainability while preserving its complete functionality.

中文Prompt：  
![](https://image.jido.dev/20260109124555_d65ac3f7)  
---  
name: code-simplifier  
description: 简化并优化代码以提高清晰度、一致性和可维护性，同时保留所有功能。除非另有指示，否则专注于最近修改的代码。  
model: opus

---

你是一位专家级的代码简化专员，专注于增强代码的清晰度、一致性和可维护性，同时保留精确的功能。你的专长在于应用特定于项目的最佳实践来简化和改进代码，而不改变其行为。你优先考虑可读、直观的代码，而不是过度紧凑的解决方案。这种平衡是你作为专家级软件工程师多年积累的成果。

你将分析最近修改的代码并应用以下优化：

1. \*\*保留功能\*\*：绝不改变代码的\*作用\*------只改变它是\*如何做\*的。所有原始特性、输出和行为必须保持原样。

2. \*\*应用项目标准\*\*：遵循 CLAUDE.md 中已建立的编码标准，包括：

- 使用带有正确导入排序和扩展名的 ES 模块

- 优先使用 \`function\` 关键字而非箭头函数

- 为顶层函数使用显式的返回类型注解

- 遵循正确的 React 组件模式及显式的 Props 类型

- 使用正确的错误处理模式（尽可能避免 try/catch）

- 保持一致的命名约定

3. \*\*增强清晰度\*\*：通过以下方式简化代码结构：

- 减少不必要的复杂度和嵌套

- 消除冗余代码和抽象

- 通过清晰的变量和函数名提高可读性

- 整合相关逻辑

- 删除描述显而易见代码的不必要注释

- \*\*重要\*\*：避免嵌套的三元运算符------对于多重条件，优先使用 switch 语句或 if/else 链

- 选择清晰而非简短------显式的代码通常优于过度紧凑的代码

4. \*\*保持平衡\*\*：避免可能导致以下后果的过度简化：

- 降低代码清晰度或可维护性

- 制造难以理解的"过于聪明"的解决方案

- 将过多的关注点合并到单个函数或组件中

- 移除有助于代码组织的有益抽象

- 优先考虑"行数更少"而非可读性（例如：嵌套三元运算符、密集的单行代码）

- 使代码更难调试或扩展

5. \*\*聚焦范围\*\*：仅优化最近修改或在当前会话中触及的代码，除非明确指示审查更广泛的范围。

你的优化流程：

1. 识别最近修改的代码部分

2. 分析提高优雅性和一致性的机会

3. 应用特定于项目的最佳实践和编码标准

4. 确保所有功能保持不变

5. 验证优化后的代码更简洁且更易于维护

6. 仅记录影响理解的重大更改

你自主且主动地运作，在代码编写或修改后立即进行优化，无需显式请求。你的目标是确保所有代码符合最高标准的优雅性和可维护性，同时保留其完整功能。

这个插件背后推荐调用的模型是Claude的Opus。

为什么要用更贵、更慢的Opus？因为重构代码这件事，容错率极低，需要极强的逻辑理解能力（也可以替换成其他家的思考模型，或者使用ultrathink这类关键词）。

让我们来分析一下code-simplifier的这段提示词，这里面藏着太多干货了。

把它拆解为五个核心维度，这也是我们在日常编程中应该遵循的几个原则。

<br />

### 1.绝对的功能守恒定律

<br />

提示词的第一条铁律就是：永远不要改变代码的功能。

这个 Agent 在工作时，所有的优化都仅限于它是怎么做的，而绝不触碰已经做好的功能。这是底线。

<br />

### 2.强制执行家规

<br />

很多朋友用Claude Code觉得乱，是因为没有家规。

这个插件会强制读取你项目里的CLAUDE.md文件。如果你在这个文件里规定了：必须用 ES modules，或者必须给函数加上类型注解。那么这个插件在打扫的时候，就会拿着放大镜检查每一行代码。

这解决了 AI 编程中最大的痛点：风格不统一。一会儿用 try-catch，一会儿用 .then()，这种分裂式的代码风格，以后再也不会有了。

<br />

### 3.清晰度大于简洁度

<br />

这是整个提示词里最让我惊喜，也是最反直觉的一点。

在编程界，尤其是极客圈子里，有一种很不好的风气，就是喜欢炫技。明明可以用三个if-else写清楚的逻辑，非要写成一个嵌套了三层、长得像天书一样的三元表达式。仿佛代码写得越短、越让人看不懂，技术就越🐮B。

官方code-simplifier插件的这个提示词，直接对这种行为说不。

它明确要求：避免嵌套的三元运算符。如果条件复杂，请用 switch 语句或者 if-else链。

提示词里原话是这么说的：Choose clarity over brevity。

翻译过来就是：宁愿代码写得长一点、啰嗦一点，也要让看代码的人一眼就能看懂。

这就像我们写文章。你是愿意看一篇全是生僻字、长难句，需要查字典才能看懂的散文，甚至是文言文，还是愿意看一篇大白话、逻辑清晰、通俗易懂的说明文？代码是写给机器运行的，但更是写给人看的。

<br />

### 4.拒绝过度简化

<br />

提示词里还专门提到了一个平衡点：不要为了简化而简化。

有些时候，为了追求极致的精简，我们可能会把很多不相关的功能硬凑在一起，或者把一些原本有助于理解代码结构的抽象层给去掉了。

这就像装修房子。极简主义是好事，但如果你为了极简，把家里的马桶都拆了，只留一个坑，那就不是极简，是简陋了。

这个让Agent懂得什么时候该删减，什么时候该保留。它不会为了减少代码行数，而牺牲代码的可维护性。

<br />

### 5.聚焦当下

<br />

最后一点也很重要，如果没有特别说明，它默认只关注最近修改过的代码。

这非常符合我们日常的工作流。你刚写完一个功能模块，趁热打铁，让它进去打扫一下。而不是每次都把整个项目翻个底朝天，那样既浪费时间，又容易因为不了解历史遗留问题而把旧代码改坏。

**如何把这个神器装进Claude Code**

安装方法非常简单，直接在终端或者Claude Code的对话框里输入命令就行。

官方提供了两种安装方式：

第一种，在终端直接安装插件：  
<br />

    claude plugin install code-simplifier

<br />

第二种，如果你已经进入Claude Code对话里了，先刷新官方plugins列表：/plugin marketplace update claude-plugins-official，然后执行如下指令安装插件  
<br />

    /plugin install code-simplifier

<br />

![](https://image.jido.dev/20260109124555_620bbb5c)

使用/plugin list检查是否安装成功了

![](https://image.jido.dev/20260109124555_00329c95)

**安装好之后，怎么用呢？**

我建议大家把它安排在PSB（三段式工作法Plan-Setup-Build）的Build 阶段的尾声。

当你完成了一个功能模块的开发，或者觉得自己刚才跟AI的对话有点混乱，代码开始变味的时候，不要急着提交代码。

这时候，你可以对Claude Code说：请使用code-simplifier帮我整理一下刚才修改的代码。

然后你就会看到Claude Code像一个经验丰富的老工程师一样，开始逐行审查刚才生成的代码。

它会把那些冗余的变量名改得更易读，把那些复杂的嵌套逻辑拆解开，把那些不符合你项目规范的写法全部纠正过来。

![](https://image.jido.dev/20260109124555_bd994233)

看着代码变干净的过程，真的非常解压。  
*PS：最好把一些个人，或者团队的代码规范在Claude.md里面写一份*

虽然这个插件是官方出的，但我不建议大家盲目照搬。

为什么？因为每个人、或者每个团队的编码习惯是不一样的。

比如，官方的提示词里有一条规则是：Prefer function keyword over arrow functions。也就是说，它倾向于使用 function 关键字来定义函数，而不是箭头函数。

但是，如果你是一个React Hooks的重度使用者，或者你就是喜欢箭头函数的简洁，那这条规则对你来说就是一种干扰。

所以，我的建议是：

第一步，先把插件装上，体验一下code-simplifier重构代码的能力。

第二步，找到这个插件的配置文件。通常在你的主目录下：

.claude\\plugins\\marketplaces\\claude-plugins-official\\plugins\\code-simplifier\\agents 文件夹里。

![](https://image.jido.dev/20260109124555_8ea8d686)

第三步，根据你自己的喜好，微调里面的Prompt。

把它当成一个模版，而不是标准。

比如，你可以在里面加上一条：所有的注释必须使用中文。或者，所有的变量命名必须遵循小驼峰命名法。

改造成一个完全懂你心意、符合你个人/团队口味的专属代码管家。

**最后**

Claude Code 这次开源 code-simplifier，其实传递了一个很重要的信号：AI 编程正在从单纯的生成代码，向代码治理转变。

之前AI编程追求的是写得快、页面炫酷、功能全面，现在开始追求写得好，在代码层面的可维护性。

对于那些非科班出身，或者独自开发的独立开发者来说，这个工具的价值是巨大的。

它相当于给你配了一个不知疲倦、水平极高、而且极其听话的技术总监，随时帮你做Code Review。

不管你是刚入门的小白，还是写了多年代码的老鸟，我都强烈建议你试一试这个插件。

它解决的不仅仅是代码质量的问题，更是我们在面对复杂项目时，那种因为失控而产生的焦虑感。

当你看着整洁的代码，你会更有信心去开启下一个里程碑。

好了，今天的分享就到这里。如果你觉得这个工具对你有帮助，或者在配置过程中遇到了什么问题，欢迎在评论区留言，我们一起探讨。

我是袋鼠帝，一个在这个AI时代，持续分享AI实践干货，陪你一起进化的数字游民。我们下期见\~

能看到这里的都是凤毛麟角的存在！

如果觉得不错，随手点个赞、在看、转发三连吧\~

如果想第一时间收到推送，也可以给我个星标⭐

谢谢你耐心看完我的文章\~
