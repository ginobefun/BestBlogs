---
title: "Claude 代码框架之战"
url: https://baoyu.io/translations/claude-code-framework-wars
---

# Claude 代码框架之战

原文：[Claude Code Framework Wars](https://shmck.substack.com/p/claude-code-framework-wars)  
作者：Shawn

### 开发者们如何通过实验各种结构、编排与标准，试图从 AI 编程中榨取更多价值。 {#p4watytqeh}

作为软件开发者，我们才刚刚开始学习如何与 AI 并肩作战。

核心思想是：**让 Claude 去做繁琐的编码工作，而你则可以抽身出来，扮演项目经理、设计师和软件架构师这些更高价值的角色。诀窍在于，别再把 Claude 当成一个聊天框，而是把它看作一个**框架 (framework)------一套能让其输出变得可预测、有价值的规则、角色和工作流。

更神奇的是，要给 Claude 套上框架，你甚至不需要写代码，只需要结构化的提示词 (prompt) 就够了。而此时此刻，开发者社区正在疯狂地进行各种实验------一场你或许可以称之为 **"Claude 代码框架之战"** 的运动正在上演。数十个开源项目正在测试各种不同的"配方"，探索如何高效地与 AI 协作。

这是一份来自前线的战地报告。
![](https://image.jido.dev/20250908030939_https%3a%2f%2fsubstack-post-media.s3.amazonaws.com%2fpublic%2fimages%2f4aca2f45-4920-4dc6-94f3-bc1269aea406_1536x1024.png)

*** ** * ** ***

一份决策"菜单" {#ptkdewwzi8}
----------------------

如果你想设计一套自己的 Claude 工作流，你需要做出以下八个重大选择：

1. 任务放哪儿？

2. 如何指导 Claude？

3. AI 智能体如何协作？

4. 如何运行会话？

5. 代码如何使用工具？

6. 代码如何开发？

7. 代码如何交付？

8. 如何保存上下文？

你可以把它想象成组建一个后厨。Claude 是流水线上的厨师，但你需要决定：菜谱放哪里？厨师们如何学习餐厅的风格？谁来管理厨房？以及，菜品如何端上餐桌？

### 1. 任务放哪儿？ {#uzzg0okutf}

Claude 需要一个单一事实来源 (source of truth)。

* **Markdown 待办列表：** 将任务以 todo list 的形式写在 Markdown 文件里。

  * *案例：* [Backlog.md](https://github.com/MrLesk/Backlog.md), [ReqText](https://github.com/fred-terzi/reqtext)。

* **结构化文本：** 明确产品规格，再将其转化为任务。

  * *案例：* [*Agent OS*](https://github.com/buildermethods/agent-os)

* **Issues/工单：** 将需求说明存为 GitHub Issues 或 Jira 工单，并将其与代码审查关联。

  * *案例：* [ccpm](https://github.com/automazeio/ccpm)

**小结：** 任务必须放在一个 Claude 看得到、你也追踪得到的地方。

### 2. 如何指导 Claude？ {#csb4yto4h6}

用结构化指令取代模棱两可的提示词。

* **命令库：** 预设的斜杠命令 (例如 /create-tasks, /review)。

* **编码标准：** 明确技术栈和编码规范。

* **完成的定义：** 将"完成的定义 (Definition of Done)"编码成规则。

* **触发验证钩子：** 在每次变更时强制执行代码风格检查 (linting) 和测试。

* **Claude 作为审查者：** 让 Claude 同时扮演开发者和代码审查者的角色。

**小结：** 规则越清晰、越可重复，Claude 的工作质量就越高。

### 3. AI 智能体如何协作？ {#s5oyobjx8c}

想用多个 Claude？给它们分配好角色和计划。

* **角色扮演：** 让 AI 分别扮演项目经理、架构师、开发者、测试工程师等角色。

  * *案例：* [Agent OS](https://github.com/buildermethods/agent-os)

* **蜂群并行：** 让许多 **AI 智能体 (AI Agent)** 在一个结构化流程中同时运行（例如：需求规格 → 伪代码 → 代码 → 测试）。

  * *案例：* [Claude-Flow](https://github.com/ruvnet/claude-flow)。

* **仓库原生工件：** 将任务、日志和架构决策记录 (ADR) 存储在代码库中，从而让记忆得以留存。

  * *案例：* [Roo Commander](https://github.com/jezweb/roo-commander)。

**小结：** 良好的协作机制能防止多个 AI"员工"互相干扰。

### 4. 如何运行会话？ {#4o6e1lkn49}

AI 的输出可能会变得一团糟------会话 (session) 就是你的工作台配置。

* **终端编排：** 由 Claude 控制命令、窗口和日志。

  * *案例：* [Symphony](https://github.com/sincover/Symphony), [Claude-Squad](https://github.com/smtg-ai/claude-squad)。

* **并行工作树：** [使用 Git Worktrees 并行运行多个分支](https://docs.anthropic.com/en/docs/claude-code/common-workflows#run-parallel-claude-code-sessions-with-git-worktrees)。

  * *案例：* [Crystal](https://github.com/stravu/crystal)。

* **并行容器：** [在隔离的容器中运行 Claude](https://docs.anthropic.com/en/docs/claude-code/devcontainer) 以避免冲突。

  * *案例：* [*ClaudeBox*](https://github.com/RchGrav/claudebox)

**小结：** 通过并行运行任务，你可以在避免持续冲突的同时，完成更多工作。

### 5. Claude 如何使用工具？ {#witzfbt5w7}

让 Claude 了解你的整个技术栈。

* **MCP 集成 (模型上下文协议)：** 捆绑的 MCP 服务器，能将 Claude 连接到外部资源------浏览器、数据库、测试运行器，甚至 UI 自动化框架。

* **自定义工具库：** 内置的 shell 脚本和命令。

  * *案例：* [*Symphony*](https://github.com/sincover/Symphony)

* **数据库访问器：** 用于增强数据库访问能力的工具。

  * *案例：* [*Claudable*](https://github.com/opactorai/Claudable)*with Supabase*

* **测试与验证钩子：** 在宣布工作"完成"前运行测试（例如 Vitest、Jest）。这将 Claude 的输出与真实的验证循环联系起来。

  * *案例：* [*Agent OS*](https://github.com/buildermethods/agent-os)

**小结：** 工具能让 Claude 从一个"聪明的自动补全"转变为一个"积极的团队成员"，它能自查工作，并与你的系统交互。

### 6. 代码如何开发？ {#z4lu4wslbu}

根据你的需要，Claude 可以戴上不同的"帽子"：

* **项目经理 (PM)：** 将产品规格转化为任务和待办事项。

  * *案例：* [ccpm](https://github.com/automazeio/ccpm), [Agent OS](https://github.com/buildermethods/agent-os)

* **架构师：** 在编码开始前，设计整体结构、定义接口并设定规范。

* **执行者：** 在设定的框架内，遵循测试和标准编写代码。

* **质量保证 (QA)：** 检查工作成果是否存在问题。

  * *案例* ：[BMAD-code](https://github.com/bmad-code-org/BMAD-METHOD)

* **审查者：** 审计合并请求 (PR) 的质量、可读性和风险。

**小结：** 在软件生命周期的每个阶段，你都可以利用 AI。

### 7. 代码如何交付？ {#1j5p6qqbfy}

代码是如何进入你的代码仓库的？

* **小步提交 (Small diffs)：** AI 领取工单并生成小的合并请求 (PR)，并且总是经过人工审查。

  * *案例：* [ai-ticket](https://github.com/jmikedupont2/ai-ticket)。

* **实验性部署：** 在功能开关 (feature flag) 后面部署变更。

* **完整应用脚手架：** AI 根据高层次的提示词构建并部署整个应用程序。

  * *案例：* [Claudable](https://github.com/opactorai/Claudable)。

**小结：** 选择适合你的规模------为生产环境选择安全迭代，为原型开发选择脚手架。

### 8. 如何保存上下文？ {#qkmat7zuj7}

Claude 会遗忘，但框架能帮你记住。

* **文档和日志：** 随时更新 CLAUDE.md、架构笔记和项目日志。

  * *案例：* [Claude Conductor](https://github.com/superbasicstudio/claude-conductor)。

* **持久化记忆与检查：** 定期回顾近期工作，运行项目健康检查，并存储决策。

  * *案例：* [Claude-Flow](https://github.com/ruvnet/claude-flow)。

**小结：** 没有记忆，AI 会重复犯错。有了记忆，它才能积跬步以至千里。

如何组合搭配 {#mo7vdizy3z}
--------------------

你可以把这些选项看作一份菜单，不必一次性点全。

* **新手套餐：** Markdown 待办列表 + 基于工单的小步提交。

* **结构化团队：** 产品规格 + 编码标准 + 角色扮演。

* **重度实验：** 仓库原生工件 + 并行会话。

* **原型模式：** 应用构建器 + 文档脚手架。

价值何在？ {#d8qkyg5o2i}
-------------------

从这场 Claude 代码框架之战中，我们得到的初步教训很简单：**给 AI 设定好框架，它才能发挥出最大效力。**

Claude 并不是要取代开发者，而是在改变他们的角色。你花在敲样板代码上的时间少了，而花在打磨需求、评审设计和定义架构上的时间多了。如果你没有尽到自己的职责，事情很快就会失控。

我们尚处于早期阶段，但各种框架的演进方向都指向同一个未来：AI 不再是一个神秘的黑盒，而是一群**由你管理的团队成员**。而这正是最激动人心的地方：你给予的结构越多，得到的回报就越丰厚。

*** ** * ** ***

原文链接: <https://shmck.substack.com/p/claude-code-framework-wars>
