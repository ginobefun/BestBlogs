---
title: "30 分钟轻松掌握 Cursor，快速提升开发效率和体验"
url: https://mp.weixin.qq.com/s?__biz=MzIzOTU0NTQ0MA==&mid=2247553100&idx=1&sn=9bf5a250d4b95d8b06e4dbd0a6451fdf
---

# 30 分钟轻松掌握 Cursor，快速提升开发效率和体验

阿里妹导读  
本文通过在WebX老项目中实践，验证了Cursor利用AI大模型可高效生成符合老旧项目规范的代码框架，显著提升开发效率与体验。  
前言

人工智能在快速发展，目前AI辅助编程也已经从简单的补全代码发展到能大规模生成代码提升开发效率的阶段，为验证这些提效方案对于各类老项目（比如基于webx开发的项目）是否同样有效，使用Cursor在老项目中开发了一个项目的模块，效果非常好，简单对话就能快速生成符合老项目规范的代码框架，对开发效率和体验的提升非常有帮助，因此总结一篇文章分享和展示Cursor相关能力。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=48900437&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU8jUULwthOKs4ZaU6Ep6T9VRHV619yf3TgFfniaSwAfC7HaME9zia1rZQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
目录

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=45eac37b&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUK5DfPLR2wSASOP96XleUJX2n7SDVy1AHjbfeffibjNXVhJk3wd3aicIg%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
AI辅助编程思想  
**普通用法**

很多时候，特别是刚开始接触AI辅助编程时，开发认为要实现极致的提效需要给出最完整的提示词，大部分精力都花在思考提示词方面，如下图：

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=1dc4aa6c&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU54b9ySfRAZplw6DCXdmXO6JAkLicRForrz0uibFL7TN85icpMfficZDOcQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

这种方法开发负担重，而且没有发挥出Cursor的强大能力。  
**高效用法**

我们可以尝试将编程的主要工作和角色交给AI，而我们主要作为方案的Reviewer对方案进行把关，其过程如下：

* 让LLM生成技术方案、开发步骤

直接提供PRD或者相关资料给LLM，让LLM根据需要自己生成技术方案、开发步骤，这个过程也可以限制使用的技术框架等。

* 使用LLM给出的方案逐步生成代码

使用LLM给出的方案逐步完成各个子模块。

* 多轮对话

在生成技术方案或者根据子方案逐步生成代码时，可以进行多轮对话不断调整，直到LLM返回满意的答案和代码。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=266cd24d&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUBy6sfhSm4QmBP3AUuDsfdHzyt7XBKNp5xmXRGicUTpELFHI6JIOJJWQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**示例：让Cursor给出开发方案和步骤**

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=4b3670f5&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU4hBd2XM7UfH5ibrTbDOZseic4dRaIVqYUO5o30GOxuibTkPcguCKcOkkw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
Cursor产品介绍  
**基本信息**

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=189187f9&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUIQtGhPjDq6Qp5lazP1bLa8icd5VDEZexmktzyS7KOYrZ2MY5sn38icgQ%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

**Cusor主页面**

大致分为几个区域：

* 文件浏览区：最左侧面板，可以浏览项目文件，该区域还可以通过顶上的按钮切换到代码管理、插件管理等区域；

* 主编辑区：中间区域的面板，这里就是写代码编辑文档的地方；

* AI聊天区：和Cursor对话，使用其核心智能辅助编程功能的主要入口；

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=163aeafd&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUWvktQttpfeOW2PB7nA4MQUJ5Uu9wFrSzdF5OS7GHku4aYibjDiaM470Q%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**Cusor的AI聊天区**

在IDE的右侧，老版本的Cursor中共分三个区域（新版本合并到了一起，为了方便了解其能力，还是按照老版本的讲解）：

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=af6c4b22&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUVibV4Bibgt2f2Ye4lQQteIG8urISokzOlb3BFzEylrev9klPYkBUHk0w%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

### CHAT区域

提供人机对话的能力，类似和gpt等对话的窗口，可以询问问题、沟通方案，这个区域唯一缺少的就是直接生成可执行代码的能力，即使生成了代码，也需要自己copy到对应位置。

* 自然语言对话: 用中文多轮交流，理解你的意图，给出精准建议或操作。

* 读懂代码: 解释函数/模块逻辑，梳理调用关系与数据流，指出风险与边界情况。

* 项目上下文感知: 结合当前工作区、已打开文件、编辑历史与项目规则进行更贴合的回答与修改。

* 文档与图: 生成或完善README/变更说明；支持 Mermaid 流程/架构图。

### COMPOSER

主要提供执行方案生成可执行代码的能力，在这个区域的对话能够生成可直接执行的代码，这些代码窗口提供接收、拒绝等按钮，如果用户接受方案，则会自动的在对应位置创建、插入显示的代码。

* 改动代码: 发起"编辑"来新增/重构/修复代码，保持原有缩进与风格，不引入 Lint 错误。

* 运行任务: 可在本机非交互地执行命令（如构建、测试、脚本），必要时后台运行并回传结果。

### BUG FINDER

用于排查问题，可以上传错误图片、粘贴异常信息，Cursor会直接给出解决方案，功能非常强大。

* 调试与排错: 结合报错信息与日志，定位根因并给出最小代价修复方案。

**引用上下文**

为了让AI更准确的回答我们的问题，生成我们需要的代码，需要引入上下文信息对AI生成的内容做约束，约束有很多，包括：项目上下文、代码规约、技术架构限制等。

cursor支持多种方式引入上下文信息，主要包括：

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=c79aa0a9&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU6ia4INYTU0v7tx0q5Oic9RZcf3rGDff2pcGAuWSRwH2fzfREN7ibfX4zA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**Notepad**

Cursor的Notepad可以方便的记录各种开发步骤、通用问题解决方案等，并且在AI对话区域方便的引用。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=6df0ee40&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUHgdCJibopf8TX84OlgLNCiasev7B2Y8vnYORgXD8ALzkXMYjABIUdpEA%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)  
**Rules**

Cusor的Rules用途很广，可以用来定义开发规范、代码风格、部署方式等，目前支持用户级别和项目级别的Rules，可以在setting面板中配置。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=176a5c7c&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUiccthJNOhib2GLicgxuawf25B0uhrBDvrXaSUGgql0OG0mvLCnmyumWCg%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

官方网站提供各种Rules

<https://cursor.directory/>

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=e0402ebc&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUzYpj5wygkNLmWoDe5gYeeCibhn25vgmJQWNMsCQvAFaEjOmCZQvFy1Q%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
实战演示

下面通过使用Cursor在老项目中实现新模块功能和重构优化代码两个场景来展示Cursor是如何给开发提效的 。相同的思路应用在完全新建的项目中更容易，提升幅度更大，本文章不做扩展。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=316d2b82&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUBa9CLQFFoqIEQ1NYzfTa0ELpoIDJduzybYNOAR65rwWa32gMDMuhBQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
使用D2C在现有项目中构建新功能

接下来展示通过Cursor在老项目中创建SQL\&Mapper、相关Bean（DO、Dao、DBService、ManageService)、Controller、HSF服务的高效过程。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=8303dcbd&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUuyErSgstX3kcFVakUJYjbEc9wzz58sAW4yMaVhLXgeORJLdkHeTTkg%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**原材料：项目设计文档**

为了快速开始，我们从近期一个项目的后端设计项目开始，该文档包括整体架构图、表设计、模块设计等，通过钉钉文档编写，最后导出为PDF上传给Cursor，为避免项目信息外泻，下面仅列出目录。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=76119ee1&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU4MS10F3ntibxicWRkTJibft6h0FdeXkU8HJa3aNibjfmD5C1s4hsBHlmYA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**让Cursor生成开发方案和步骤**

无需过多考虑，直接上传设计文档让Cursor给出开发方案和步骤，可以看到，Cursor给出了一系列的方案和步骤，这里可以多轮对话不断调整细节。

一些通用方案（比如要求使用springboot、mysql等）还可以沉淀到Notepad或者Rules中，这样Cursor以后生成的方案中就会默认包含该部分规则。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=7c8f6320&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUq3AeYz5ytV8V3uVEb0VWMoicRIB5fWrwWAdD2c4liagX6qwU6ic8ysmyQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)![](https://wechat2rss.bestblogs.dev/img-proxy/?k=49e2b237&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUYms58CKP3JWvHFANxnwicnMbWHO0nTmSPicBhJTNcHk7Vicib2ont1DBhA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**创建SQL与MAPPER**

接下来开始生成具体代码，可以按照Cursor给出的步骤逐步生成，也可以按照自己的开发习惯生成，上面对话除了生成步骤外，也主要为了给Cusor引入上下文。

本文为了更清晰直接的演示Cursor各个层面的生成能力，拆解出了多个细节任务执行，实际使用时在完善了Notepad、Rules（如需要）后可以直接使用Cursor给出的步骤进行生成，使用方法很简单，将Cursor生成的每一步内容copy进聊天框让它执行即可。

提示词识别表和生成建表SQL

简单给出提示词，要求Cursor生成相关表和Mapper。

(注：Cursor理解PDF过程中可能会要求执行一些命令，判断无风险可放行)

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=df2bf9db&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUpEym4OtVuzu5Mr4AfQl8VF3Wg3lfwf3BTxE31BVb5sMicebFJ9OFYicw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor给出表及建表语句

这里Cursor根据识别到的信息生成表及其Create脚本，共计25个文件，篇幅原因这里只展示其中一个表的生成代码。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=5cb67197&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUPX1oww5IBk8fDQFWoP1MDDke8NZoqsOKW8yicicU0IWFkR9iaC6zLJmyw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

给出模版让Cursor生成Mapper

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=868bc64f&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUlZTBMnljy8qlO7WeMQZWgu4xHRdyhqdplB8MkU19hV1VLOdKorDUGQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor生成Mapper文件

可以看到Cursor生成的代码有以下几个特征和模版文件一致。

* 生成的Mapper结构与模版一致，包括在文件顶上配置resultMap定义、提供load查询方法等；

* 开头使用DO定义别名；

* 用一个SQL模版包含所有字段；

* 相关查询中引用模版SQL；

  ![](https://wechat2rss.bestblogs.dev/img-proxy/?k=bdb6a4fd&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUuO2ORL3eD6fpaTVsCEq4rSJgaQcEqZMT4WGwxOCZichwcBDiaHNVdDnQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

发现缺失模版中的一些特性

#### 缺失了commonCondition部分内容

模版mapper里定义了各个字段在where查询里的通用模版，第一次生成时Cursor没有生成出来。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=9ef6b467&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUONDml0Qq1GYU26qtFQmKWdXga5iaDy5HkO4OLPPIsdFLqf7f4NZzzBQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

要求Cusor调整

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=ccd519c3&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU61zeiaqfwqpls9505FN8aHK1zqUsoCs8sdKrvDjg4hTZ4GibSKALqibqQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cusor给出了修改内容

不仅生成了通用模版，还自动加到了查询的where条件里。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=7e688669&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUiaa8iaWW3qqmFdU9IxTHCemWj7wG3AA2MUDoGZXyYtCnNkRLxEEIllKw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

要求进行更多调整

#### 补充set、pageConditions、reset需求

模版Mapper中还包括set、reset、pageConditions等通用sql，要求Cursor一一添加。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=38fe4046&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU33Svb2s9tib8hLsLkKib4iaB0V2ibPhJvNzRqw6zdnZXxfFgiawHBtBYKOw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cusor进行相关调整

Cursor参考模版内容进行了添加，并自动追加了where查询和update语句里。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=18566b7a&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUBpG6f8IG2XDO13BUWhywC9jnwWfUibHyx6GWcrICWqRYwvqnicHtnnWw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**让Cursor参考项目模版生成骨架**

这个项目的规范里每个领域对象都包含了ManageService（业务逻辑层）、DBService（数据逻辑层）、Dao（数据服务层）、DO，要求Cursor参考现有项目风格生成代码。

@codebase 命令使用后Cursor会自动参考项目结构生成相关代码。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=d862b99d&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUia6ac1SRiapfw6u1w94HN63w2srKsR2gh3ehwwgXxv5riakmbMOPOrwcQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor参考项目生成DO

从DO开始，Cursor生成的Bean里自动继承了项目里所有领域实体对象DO的父类、属性具备驼峰规则、同时提供了get/set方法，这些都符合项目要求和开发规范。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=636ed6e9&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUOYUBibgonJic0OdhX5qwGMd9PDbYZjFJKjv8yIERftHc0Vp3UXza4Xicw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor参考项目生成Dao

同样，生成的Dao也继承了所有Dao的父类，并且泛化类型匹配正确。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=e6e5982a&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU10K4kM7ErQoxppdmaq5UxiaNBspwKdzSKEMOaSoQ9CkXNRon1PkjmRA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor参考项目生成DBService

生成的DBService同样继承了所有DBService的父类、泛化类型符合要求，同时还和其他DBService实现类一样复写了getKey、setKey、getCondition几个关键方法，这些都是项目独有的结构，生成的非常好。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=652dc271&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUbzsD9oOkeKfTGxgVKlARftHv66JroSlMibfbDWQ1XgTia6sn2pNbMEEg%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor参考项目生成ManageService

最后是ManageService，这一层唯一的特殊点就是项目中每个ManageService基本都会引用自己的DBService，Cursor也能正确识别并参考这个风格生成代码。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=77785ffc&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU2svxO8vl4YZ5ueWY6dibos3ib0Fibwiby5eZVhuX3NgEkEtcCrGY4AL1iaw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=74038743&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUf4EHoibctL19g2pQjfvrnpr1ebZDcTs24vHUpfJ5zDTPk1okbLc65ibw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**Cursor参考项目生成Spring配置**

接下来是生成spring等相关配置文件。

### 提示词

使用@codebase 简单描述我们的需求，Cursor就能够生成符合项目风格的配置文件。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=3aef529d&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTURnibojvICA1faAaZGkXAxW7hKMJlYxAaHdsH19gBiapU361DwFWaKt1Q%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor参考项目生成相关Spring配置文件

* Dao的配置和项目中其他Dao的配置一样，继承了通用的baseDao；

* 新增Bean的spring配置自动生成并能追加到配置文件中；

* 参考项目结构在sql文件中自动追加了mapper的配置文件；

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=bf1e7d1c&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUTiaMzKRiamYsXpw24WqmV8kM0a2LtMibBuviaPgxgiaQ7EMoUgvheFXty1Q%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**创建Controller**

由于采用微服务架构，通用代码在一个工程里，部署的web应用、HSF服务等在另外一个应用里，如果在Cursor中打开新工程是无法自动传递聊天记录的，这里需要用到一些技巧。

* 通过chat的导出功能从上面工程中导出之前的对话内容；

* 在web应用中新建notepad保存这个对话内容，命名为"shareProjectChatNote"；

* 在后续对话中引用这个notepad；

### 使用notepad传递对话内容

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=890373e5&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUMZH3jMib2nTCJAdhhsW83PKLIWkr1viawoiaEIPmZtnKIBicGkqHzteSLA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

让Cursor参考项目需求生成相关Controller

引用notepad在这个新工程中延续我们之前的对话内容，并描述生成Controller的需求。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=7272ec91&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUwWftWuac9Ibp55lzfA42OODw1jZP7mtbic4dlLBckvpHeL0TmiaoZOow%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor生成了基于SpringMVC的Controller

由于没有指定技术框架和其他限制，Cursor根据常用的SpringMVC框架生成了Controller的内容，如下：

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=c82f0b63&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUnKv2YDqE8nkVD3ffLCqrA5ryS8gjoMxFB0zS5lVvEPHvT0DxbFFEgw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

让Cursor按照webx风格生成相关Controller

我们是webx的工程，因此使用@CodeBase 指令让Cursor参考现有项目结构和风格生成代码。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=8a0a870d&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUSVibfRP9ZrEgaUiblVDajBLf38DicTp6fxibY6XygG0egDTGFlWpqmK39Q%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor生成了基于webx的Controller

Cursor在不理解webx完全内容的情况下，参考现有工程的编码风格，生成了符合webx和项目使用规范的代码：

* 使用webx专用的注解 @WebResource @ResourceMapping开放服务；

* 接收参数的对象也使用了webx的专用注解 @RequestParams；

* 除此之外，Cursor还识别到了项目中经常使用@NoneResultDecrator这个注解，该注解是项目自定义的，用来告诉webx不要在返回结果外部再套一层json对象，直接返回方法返回的内容；

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=8cd72062&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU36pqjPl2P7Lialv4hl0mWZgJwib4jy0NfWHkVicEINcicQwjY2SbID8biaQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**创建HSF服务**

HSF并不是这个项目的开发内容，但是为了测试Cursor对项目相关功能的支持程度，因此也做了一下实践，效果非常的好。

创建HSF编码规范RULE

为了让Cursor生成符合我们要求的代码，我们创建一个项目级的Rule，将项目的编码规范加入其中，为了验证Cursor是否真的按约定的规范生成代码，这里我们留意以下几点：

* 服务需要实现读写分离，读服务都放在xxxReadService里，写服务都放在xxxWriteService里；

* 分页和不分页的接口参数对象、返回结果需要继承不同的对象；

  ![](https://wechat2rss.bestblogs.dev/img-proxy/?k=a0b62f4d&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUe1vMEvibawF4oQJ7iabiajTo1J08DEmVCB54RUPt0MAAfbXqxNfg9LLbA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

让Cursor构建HSF服务

通过@Rules 选择刚才的编码规范rule后，告诉Cursor生成我们需要的服务。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=4dc4fcd6&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUV5ryYJnpcAta70ICUJbSsYK3jSZticzcMYMcLX5D8x1PehGujm0BxicA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

Cursor生成读写分离的接口定义

Cursor生成的代码如下，可以看到虽然有一些瑕疵，但整体还是符合我们的规范的，包括：

* 实现了读写分离

这里有一些瑕疵，规范里是要求使用xxxReadService，这里使用了QueryService，可能是下面的命名规范有冲突，可以调整规范或者将采纳策略补充到Rules或者Notepad中进一步说明，避免以后再犯。

* 接口参数以Request结尾、返回对象以Result结尾。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=2f986f50&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUpBWw7aaicHVOSzVFBsicF4zREO6cLenZm98NjfLmD7IxuDoDkQR3ZFMQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=75b0dec1&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUybkNFUVhJzVUVZbtgE1SfA5eITwZgO6KXHUoqlNtteic8eJlWRFicGCw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

请求、结果对象符合编码规范

非分页接口参数对象继承了AbstractAclAppTenantRequest对象，结果对象继承了AbstractBaseResult对象，泛化对象与期望的相符。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=5350c510&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUxLqz6FPHND2XJJeJjwTGYAk6yDcAU6ROZKMmK8snPxiapopibfUmrr9A%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=bb6ab207&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUiaheatlaHH49vwiawkvwbECoZYYVrS7ojCOOCzlmDyX5EsiaxXD6lE97w%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)

实现类里也能正常调用项目方法

实现类里包含了对项目中各个API的正确使用。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=dcfa6532&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU8Ue4vaicoibIMzeCeDEriaRviaQkpE7sV37KRqCJUVBZsTRRyYe3h7PKXw%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**十二轮对话生成项目主要内容**

总结一下，除了生成HSF外，我们通过大约十二轮简单的对话就生成了这个项目的主要代码内容或者框架，可以继续对话优化细节，或者是将遇到的问题及其解决办法存放到notepad中，避免以后的代码生成时再犯。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=615f0ce9&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUgUMbsZW19Qv8qEy4qibwx0oicxUgia7Nb4CN9G9QWvnYoZYEjB5wNhibPQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
代码优化与重构

接下来展示Cursor对代码重构和优化的帮助。  
**一个有很多ifelse的代码段**

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=5252b529&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUBvAKUGT4gVqbFLTh5CuFiaJ774lT0yfQY5Kib8g9vc9TmGgtK5dXic8TQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**让Cursor进行优化**

编辑器中使用command+k唤起AI对话框，输入我们希望Cursor做的工作。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=82bd2310&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU2H0SVV8UTz9afv92ndSLZClPUMClOa5WRgwplvOZjoKz8fN9ciaQZOg%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**Cursor抽象了逻辑行为、封装了重复调用、**

**优化了方法主流程**

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=c42e9c43&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUstLmbMjbchPs9rkUW4glfwsqbl7jfbsToKpqDS54ClcJm1ibx0pTVOA%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
小帖士  
**切换到Agent模式**

如果想让cursor生成代码，直接给出解决方案，需要在对话框中切换到agent模式，普通聊天模式不能完成该任务。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=c7e917e3&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUYtHzgegcp3fCv975nxPvLcscIicuNqpks7dDJDhZj2Ca2O1QjskEDUQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**快速调出对话框生成代码**

在编辑窗口可以使用command+k（mac）的方式唤起AI对话框，输入需求生成代码。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=d5c2f296&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUUblCP1Qiataj7LiakPcbHWxQGuD4ricBtsw3FTibbSauyaGa3diaPWs8A2A%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**生成内容都可以接受、拒绝**

Cusor生成的所有内容都附带了接受、接受全部、拒绝、拒绝全部的按钮，可以根据需要自由选择。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=a4e73a28&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTUYjF2IOp1aO60lx9zXazNBoIW1iaeDYeeetobE8qnCwicvTiacZolNRLTg%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
**配置各类模型**

Cursor内置了很多模型，也可以自己配置其他模型，但是自己配置的模型有可能不支持代码的自动创建。

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=8bcf25cb&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_jpg%2FZ6bicxIx5naLplhpfKr6aTFfqRMEHWFTU0M9TYsy2AA9Od89obVvZMkvCOaUKjc63g7DIiciaJa10SuEU732mmswQ%2F640%3Fwx_fmt%3Dother%26from%3Dappmsg)  
结尾语

Cursor用下来感觉是个非常强大的工具，以上案例并没有展示它的所有能力，需要在项目中持续实践，不断积累问题和解决方案，添加到上下文Nodepad、rules中才能使Cursor生成的代码不断接近我们期望的样子。  
**MCP+Cursor = 王炸**

Cursor还可以和MCP结合，实现更大范围的基础设施自动生成，比如自动创建项目需要的流程、账号、权限等。这部分还需要各类平台升级提供相关MCP能力后才能不断完善和发展，但是可以预见会带来非常可观的效率提升和开发体验提升。
