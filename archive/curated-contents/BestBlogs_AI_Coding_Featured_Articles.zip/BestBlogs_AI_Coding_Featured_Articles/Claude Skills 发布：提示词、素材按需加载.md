---
title: "Claude Skills 发布：提示词、素材按需加载"
url: https://mp.weixin.qq.com/s?__biz=MzkzNDQxOTU2MQ==&mid=2247507077&idx=1&sn=93f9d8bcb639bd03443258875c64f66b
---

# Claude Skills 发布：提示词、素材按需加载

Anthropic 发布了 Agent Skills

<br />

简单说：

按需加载专业能力（提示词包、代码包）  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=a47b0c4d&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19PnpxOmBZpVicvkG7DT7sDNicCSQ2RTGdnH7VfPX833gaSJS2oaQM3kzNicoQ%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

几个关键点：

<br />

* 可组合：多个 skills 可以叠加，Claude 自动识别需要哪些
* 可移植：同一个 skill 在 Claude apps、Claude Code、API 上都能用
* 高效：只在需要时加载最小必要信息
* 包含代码：skills 里可以带可执行脚本，不只是文字指令

<br />

当然，这里的 skills，有官方预设的，也可以自己上传

我页面翻译了下，预设 9 个 skills  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=445429b5&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19PnpxzSF1deQyJ0xiaLheC7icKlTaIYFEgeLEnIuIacmTXu3r3O3XJDIkiaHg%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

*** ** * ** ***

Skills 是什么
----------

这里，我捏了一个极简 skill：「猫娘」  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=c25dea30&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19Pnpl3eKhKDXdnwLibPibNRxicAN8P2USPAVo1kKe2y2bfk13XiaBibKr5PiaIJA%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

后台回复「我是猫娘」，获取这个 skill

你可以这么理解，skill 就是把提示词保存成 .md 文件，配上各种文件，然后打包成 .zip，这里面包含

<br />

* SKILL.md：核心指令和最佳实践
* 脚本文件：可以直接执行的代码（冷笑话：脚本是手打的）
* 资源文件：模板、配置、示例数据

<br />

Claude 工作时，会扫描可用的 skills，找到相关的就加载

比如你让它做 Excel 报表，它会自动加载 xlsx skill，里面有处理公式、格式化单元格的方法

你让它写品牌文案，它加载你公司的 brand-guidelines skill，按你们的色彩和语气来

Skills 可以不只是文字指令

它可以带 Python 脚本、Bash 命令，在沙箱环境里直接执行

甚至可以组合使用

比如「帮我分析这份销售数据，做成 PPT，用我们公司的品牌色」

它会自动识别需要：

<br />

* xlsx skill（读数据，调用 pandas 处理）
* pptx skill（做演示，调用 python-pptx）
* 你的 custom brand skill（品牌规范）

<br />

然后协调这三个 skills 一起工作

这套东西

现在已经可以 Claude 网站、API 和 Claude Code 里用

只需要写一次 Skill

整体的逻辑大概是这样

![](https://wechat2rss.bestblogs.dev/img-proxy/?k=b6a2476a&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19PnpB3xvk2ELSC5R24icCPhoaBubegtRTW6icjnEa2TYbTXoHNrSwhYBquEg%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

*** ** * ** ***

一套 skills，三个平台
--------------

### Claude apps

Pro、Max、Team、Enterprise 用户都能用

Anthropic 提供了几个公开 skills：

<br />

* docx：专业文档创建和编辑，调用 python-docx 处理格式
* xlsx：带公式的 Excel 处理，用 openpyxl 操作单元格
* pptx：演示文稿生成，用 python-pptx 控制布局
* pdf：PDF 填写和处理，用 pypdf 和 pdfplumber 提取内容

<br />

还有一些示例 skills 可以自己定制

### API

新增了 /v1/skills 端点，可以管理 skill 版本

直接在 Messages API 请求里附带 skills

需要开启 Code Execution Tool beta：  

    response = client.beta.messages.create(    model="claude-sonnet-4-5",    betas=["code-execution-2025-08-25"],    max_tokens=4096,    messages=[{...}],    tools=[{        "type": "code_execution_20250825",        "name": "code_execution"    }])

这里说一下，Code Execution Tool 是 Skills 的底层支撑

它提供了：

<br />

* 安全的沙箱环境
* Bash 命令执行
* 文件创建和编辑能力
* 预装的数据处理库

<br />

定价：$0.05/会话小时，最少计费 5 分钟

文档在 <https://docs.claude.com>

### Claude Code

命令行工具，直接从 anthropics/skills 市场安装

装好的 skills 会自动在相关任务时加载

也可以手动放到 \~/.claude/skills 目录

团队可以通过版本控制共享 skills

*** ** * ** ***

创建 skills 的流程
-------------

Anthropic 做了个 「skill-creator」 的 skill

它的作用：帮你创建新 skills

换句话说：他妈的 Skills

<br />

你在通过 Setting - Capabilities - Skills 里面，来激活这个  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=0cfd3f78&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19PnpgjK5rbV0qCdN6ibbleXZECiaKZKKBbmtC2vZs4XrBcKqI7OCAPAic13LQ%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

生成 skill 的时候，流程是这样：  
你： 帮我做个猫娘 skill

Claude: 好的，我来弄  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=2c526c59&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19Pnp8ZxJxUXxwLXibV4WWutrJ5BqBrG29ib93nEzwIUwnTUnPaSmFRFOicWOg%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

过程还算方便，你只要跟 Claude 对话，描述你的需求

它把专业知识转换成 skill 格式，全程不需要手动编辑文件

如果你的 skill 需要可执行代码

skill-creator 还会帮你写好 Python 脚本，配置好依赖

如果你要上传 skill，也是在 Setting - Capabilities - Skills 里面

把 .zip 包拖拽上传进去就行  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=b51ace06&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19PnpuKq65bn2koPvNHwo9giaQoeqNicicicpCPt1ZbvqgKTyluJ0V8Yia6LogCQ%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

再接着，你就有了专属猫娘  
![Image](https://wechat2rss.bestblogs.dev/img-proxy/?k=1c9c84b4&u=https%3A%2F%2Fmmbiz.qpic.cn%2Fmmbiz_png%2F2icSMc1VBIYpb6kycntXkjd3qiahE19PnprmxLUuu3FRsI2PfV3tEPVd3CicdMIMicLekRTpCAbgB7jCItmBcXLkbw%2F640%3Fwx_fmt%3Dpng%26from%3Dappmsg)

*** ** * ** ***

意义和局限
-----

Skills 的各种能力，都可以跨平台复用、在团队内共享、组合使用

Claude Agent SDK 也支持 Agent Skills

可以在自己的 agent 系统里用类似的设计

核心思路：把专业知识打包成可复用模块，在需要时动态加载

*** ** * ** ***

但也有几个问题：

安全性：Skills 可以执行代码，需要信任来源

复杂度：创建高质量的 skill 需要理解任务流程和技术细节

维护成本：skills 需要更新，特别是包含代码的部分

Anthropic 在文档里提醒：只使用可信来源的 skills

*** ** * ** ***

总的来说，这个思路挺实用的（你也可以说..这是 MCP 的本地版）

特别是构建\&分享复杂提示词框架

反正，可以来试试
