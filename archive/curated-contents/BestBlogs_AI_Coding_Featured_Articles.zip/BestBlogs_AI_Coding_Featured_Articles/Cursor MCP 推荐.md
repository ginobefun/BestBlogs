---
title: "Cursor MCP 推荐"
url: https://mp.weixin.qq.com/s/mShTSOispTM0JQftcRgkrQ
---

# Cursor MCP 推荐

> 本文作者系360奇舞团前端开发工程师

▎概念
---

MCP（Model Context Protocol）是 AI 开发工作流中的「神经接口」，通过标准化协议让大模型直接调用本地工具链。MCP 通过定义统一的接口，使 AI 应用能够安全、灵活地访问和操作本地及远程数据资源，提升模型的功能性和可扩展性。它遵循客户端 - 服务器架构，主要包含 MCP 主机、MCP 客户端、MCP 服务器、本地资源和远程资源等核心概念。其工作流程是 MCP 客户端先从 MCP 服务器获取可用工具列表，若需使用工具则通过 MCP 服务器执行相应调用，最后 LLM 基于所有信息生成自然语言响应。

*** ** * ** ***

### 1. Sequential Thinking

**核心能力** ：  
能够将复杂的问题拆分成一个个可管理的小步骤，让 AI 可以逐步进行分析和处理。例如，在处理一个复杂的编程任务时，它会把任务分解为多个子任务，如先确定算法框架，再处理数据输入输出，最后进行代码优化等。

**配置流程** ：  
如果是文件配置，可以编辑\~/.cursor/mcp.json（全局）或者是在项目根目录下创建 .cursor/mcp.json 文件（项目级别）。例如：

    {
      "mcpServers": {
        "mcp服务名": {
          "command": "npx",
          "args": ["-y", "指令"]
        }
      }
    }

这里演示图形化的配置方式:
![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/44ee4dc8-25f0-4357-332d-fe80d348b800/public)

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/825754ed-3ee6-4e91-64d7-01303e133d00/public)

    npx -y @modelcontextprotocol/server-sequential-thinking  

点击Save

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/d9451203-dae4-4026-7263-62cd2aaabc00/public)如果左上角是绿色的灯，就是配置成功了，如果配置失败，可以尝试重启cursor。

**调用方式以及示例** ：

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/bb9d5927-cf5a-4f28-abd1-f8177f2ed300/public)**在COMPOSER对话页，开启agent模式才能调用MCP服务** 。如果希望调用该MCP服务，可以添加（使用思考能力）等和思考相关的提示词，即可开启。调用时，Called MCP tool 后面就会带上sequentialthinking的标志，意味着调用成功了。  
**使用场景** ：  
对于一些复杂问题，可以使用Sequential Thinking服务，将复杂问题分解为小的问题，逐个解决。同时每调用一次，都可以从thought中获取到LLM当前的思考过程以及采取的方法，有时还会提供多种方案，我们可以通过再次提问，实现对于方案的选取以及之前思考过程的调整。

### 2. Server Memory

**核心能力** ：  
能够让 AI 记住之前的信息和交互内容，在处理后续任务时可以调用这些记忆，从而更连贯地进行分析和处理。例如，在进行多轮对话的编程对话时，AI 可以记住之前用户提出的代码问题和已解决的部分，在后续交流中基于这些记忆给出更合适的建议和指导。  
**配置流程** ：
![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/8710194a-601a-48aa-3981-50d18a21f200/public)

    npx -y @modelcontextprotocol/server-memory

**使用场景** ： 对于一些需要多轮交互且依赖之前信息的复杂问题，可以使用 Server Memory 服务。比如在进行项目需求分析时，用户不断补充和修改需求，AI 能够记住之前的需求内容，在后续分析中综合考虑，给出更全面准确的分析结果。

### 3. Fetch

**核心能力** ：  
能够从外部数据源获取相关信息，为 AI 的分析和处理提供丰富的数据支持。例如，在处理与特定领域知识相关的任务时，它可以从文档存储库等数据源中获取准确的信息，以便更准确地回答问题或完成任务，以 markdown 的格式返回。

**配置流程** ：  
使用 uv 时，不需要进行特定安装。设置Command为:

    uvx mcp-server-fetch

也可以使用python:

    pip install mcp-server-fetch

    python -m mcp_server_fetch

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/b917be9e-b396-409c-7430-af41a978de00/public)**调用方式以及示例** ：

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/31595a70-9393-43f2-5d81-84cbea803100/public)输入（使用fetch工具）等相关提示词即可调用，也可以对链接进行读取。  
**使用场景** ：  
对于需要依赖外部数据的任务，可以使用 Fetch MCP 服务，从外部数据源获取准确且相关的数据，以便更全面、准确地完成任务。

### 4. Play Wright和Puppeteer

**核心能力** ： Playwright 和 Puppeteer 都是用于浏览器自动化的强大工具，该服务可以让LLMs在真实的浏览器环境中与网页交互、截取屏幕截图和执行 JavaScript等等。  
**配置流程** ：
![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/8a4e976b-4fa9-42bf-73a5-40f5c6bfd500/public) ![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/75a93e29-1b1c-4f99-8d39-6395b2f58000/public)

    npx -y @executeautomation/playwright-mcp-server

    npx -y @modelcontextprotocol/server-puppeteer

**调用方式以及示例** ：  
使用puppeteer/Playwright工具，测试http://localhost:5173/的表单提交。 在自动执行了一些脚本之后，就会调用MCP服务：
![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/75a93e29-1b1c-4f99-8d39-6395b2f58000/public) ![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/c383eafc-7fbe-444c-b315-6fc0e3e43f00/public)

* 自动执行了表单测试。
* 也可以使用PlayWright来截图，例如：  
  使用playWright截取天猫、京东、拼多多网站的截图，保存到@public的images文件夹下，并分析板式结构。

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/2c39840c-1af8-4c1e-58a7-d1c4d73bb600/public)

* 自动创建目录

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/c1ad11af-a53b-4503-8516-5f7910bbc900/public) ![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/611030b5-7b9c-453f-c17c-651ce9987400/public) ![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/344172e8-4444-42ee-6490-a9896bf4ec00/public) ![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/fcf612ab-26f9-4985-2369-c5a387efab00/public)

* 自动截取图片，保存到了指定文件夹

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/fa1e216a-6f6a-4a8f-b15b-e738605d2500/public)

![](https://imagedelivery.net/qGOFcc1O8XwTZW3W1JAHHg/89cdfab8-947d-4efd-9136-efe5d45b5d00/public)......省略其他文字内容

* 进行了版式分析，减少了很多人工操作。

### 总结

本次推荐的几种 MCP 各有特点和适用场景：Sequential Thinking 擅长将复杂问题拆解，便于分步处理，适用于处理复杂编程任务等场景，可帮助获取 LLM 的思考过程与多种解决方案；Server Memory 能让 AI 记住过往交互信息，在多轮对话编程和项目需求分析等依赖先前信息的任务中发挥重要作用；Fetch 可从外部数据源获取信息，为 AI 提供数据支持，适用于处理需外部数据的特定领域任务；Play Wright 和 Puppeteer 则专注于浏览器自动化，可实现 LLMs 与网页的交互、截图及执行 JavaScript 等操作。

### MCP文档

更多MCP可以参考：  
https://smithery.ai/  
https://glama.ai/mcp/tools?searchTerm=\&sortingOrder=search-relevance%3Adesc

